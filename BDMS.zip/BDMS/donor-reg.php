<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Donar Registration</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <style>
        #form{
    /* padding: auto; */
    width:50%;
    height:88%;
    background-color: #ffb3de;
    color: black;
    border-radius: 10px;
}
input[type=submit]
{
    padding: 10px;
    background-color: #ffb3de;
    color: black;
}
    </style>

</head>
<body>
<div id= "full">
    <div id="inner_full">
        <div id="header"><a href="admin-home.php"><h1>Blood Donor Management System</h1></a></div>
        <div id="body">
        <br>
        <?php
        $uname=$_SESSION['uname'];
        if(!$uname)
        {
            header("Location:index.php");
        }
        ?>
        <h1 style="color:#c71585">Donor Registration</h1><br>
        <div id="form">
            <form action="" method="post">
            <table>
                <tr>
                    <td width="100px" height="75px" >FULL NAME</td>
                    <td width="100px" height="75px"><input type="text" name="name" placeholder="Enter Full Name"></td>
                    <td width="150px" height="75px">MOBILE NUMBER</td>
                    <td width="100px" height="75px"><input type="text" name="mnum" placeholder="Enter Mobile Number"></td>

                </tr>
                <tr>
                    <td width="100px" height="75px" >AGE</td>
                    <td width="100px" height="75px"><input type="text" name="age" placeholder="Enter your Age"></td>
                    <td width="150px" height="75px">GENDER</td>
                    <td width="150px" height="75px">
                        <select name="gender">
                            <option>Select</option>
                            <option>Female</option>
                            <option>Male</option>
                        </select>
                    </td>

                </tr>
                <tr>
                    <td width="125px" height="75px" >BLOOD GROUP</td>
                    <td width="125px" height="75px">
                        <select name="bgroup">
                            <option>Select</option>
                            <option>A+</option>
                            <option>A-</option>
                            <option>B+</option>
                            <option>B-</option>
                            <option>AB+</option>
                            <option>AB-</option>
                            <option>O+</option>
                            <option>O-</option>
                        </select>
                    </td>
                    <td width="150px" height="75px">MAIL-ID</td>
                    <td width="150px" height="75px"><input type="text" name="email" placeholder="                      @gmail.com"></td>

                </tr>
                <tr>
                    <td weight="75px" height="100px">ADDRESS</td>
                    <td width="250px" height="100px"><textarea name="address" rows="4"></textarea></td>
                </tr>
                <tr>
                    <td weight="75px" height="40px"></td>
                </tr>
                <tr>
                    <td><input type="submit" name="submit" value="SAVE"></td>
                </tr>
            </table>
    </form>
    
    <?php
    if(isset($_POST['submit']))
    {
        $name=$_POST['name'];
        $mnum=$_POST['mnum'];
        $age=$_POST['age'];
        $gender=$_POST['gender'];
        $bgroup=$_POST['bgroup'];
        $email=$_POST['email'];
        $address=$_POST['address'];
        $q=$db->prepare("INSERT INTO donor_registration (name,mnum,age,gender,bgroup,email,address) VALUES(:name,:mnum,:age,:gender,:bgroup,:email,:address)");
        $q->bindValue('name',$name);
        $q->bindValue('mnum',$mnum);
        $q->bindValue('age',$age);
        $q->bindValue('gender',$gender);
        $q->bindValue('bgroup',$bgroup);
        $q->bindValue('email',$email);
        $q->bindValue('address',$address);
        if($q->execute())
        {
            echo "<script>alert('Donar Registration Successfull')</script>";
        }
        else{
            echo "<script>alert('Donar Registration fail')</script>";
        }
    }
    ?>
        </div><br>
    
    </div> 
    
    <br><br><br><br><br><br>  <br><br>
    <div id="footer"><h3 align="center">Copyright@DBP2021-B07</h3>
    <p align="center"><a href="logout.php"> Logout</a></p></div>
    </div>
</div>
</body>
</html>