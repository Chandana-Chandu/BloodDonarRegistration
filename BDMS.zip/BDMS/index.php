<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <style>
        input[type=submit]
{
    padding: 7px;
    background-color:#32174d;
    color:white;
}
    </style>
</head>
<body>
<div id= "full">
    <div id="inner_full">
        <div id="header"><h1 align="center">Blood Donor Management System</h1></div>
        <div id="body">
            <br><br><br><br><br>
            <form action="" method="post">
            <table align="center">
            <tr>
                    <td width="200px" height="70px"><b>Enter user-ID</b></td>
                    <td width="200px" height="70px"> <input type="text" name="id" placeholder="Enter User-ID" style="width:180px;height:30px;border-radius:10px"></td>
                </tr>
                <tr>
                    <td width="200px" height="70px"><b>Enter username</b></td>
                    <td width="200px" height="70px"> <input type="text" name="uname" placeholder="Enter Username" style="width:180px;height:30px;border-radius:10px"></td>
                </tr>
                <tr>
                    <td width="200px" height="70px"><b>Enter Password</b></td>
                    <td width="200px" height="70px"> <input type="text" name="pass" placeholder="Enter Password" style="width:180px;height:30px;border-radius:10px"></td>
                </tr>
                <tr>
                    <td> <input type="Submit" name="sub" value="LOGIN" style="width:70px;height:30px;border-radius:5px;"></td>
                </tr>
            </table>
            </form>
            <?php
            if(isset($_POST['sub']))
            {
                $id=$_POST['id'];
                $uname=$_POST['uname'];
                $pass=$_POST['pass'];
                
                $q=$db->prepare("SELECT * FROM admin WHERE id='$id' AND uname='$uname' AND pass='$pass' ");
                $q->execute();
                $res=$q->fetchAll(PDO::FETCH_OBJ);
                if($res)
                {
                    $_SESSION['uname']=$uname;
                    header("Location:admin-home.php");
                    $q1=$db->prepare("INSERT INTO login (id,uname,pass) VALUES(:id,:uname,:pass)");
                    $q1->bindValue('id',$id);
                    $q1->bindValue('uname',$uname);
                    $q1->bindValue('pass',$pass);
                    $q1->execute();
                }
                else
                {
                    echo "<script>alert('Wrong User')</script>";
                }
            }
            ?>
        </div>
        <div id="footer"><h3 align="center">Copyright@DBP2021-B07</h3></div>
    </div>
</div>
</body>
</html>