<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Exchange Blood Donar Registration</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <style>
        #form{
    /* padding: auto; */
    width:50%;
    height:430px;
    background-color: #ffb3de;
    color: black;
    border-radius: 10px;
}
input[type=submit]
{
    padding: 10px;
    background-color: #ffb3de;
    color: black;
}
    </style>

    
</head>
<body>
<div id= "full">
    <div id="inner_full">
        <div id="header"><a href="admin-home.php"><h1>Blood Donor Management System</h1></a></div>
        <div id="body">
        <br>
        <?php
        $uname=$_SESSION['uname'];
        if(!$uname)
        {
            header("Location:index.php");
        }
        ?>
        <h1 style="color:#c71585">Exchange Blood Donor Registration</h1><br>
        <div id="form">
            <form action="" method="post">
            <table>
                <tr>
                    <td width="100px" height="75px" >FULL NAME</td>
                    <td width="100px" height="75px"><input type="text" name="name" placeholder="Enter Full Name"></td>
                    <td width="150px" height="75px">MOBILE NUMBER</td>
                    <td width="100px" height="75px"><input type="text" name="mnum" placeholder="Enter Mobile Number"></td>

                </tr>
                <tr>
                    <td width="100px" height="75px" >AGE</td>
                    <td width="100px" height="75px"><input type="text" name="age" placeholder="Enter your Age"></td>
                    <td width="150px" height="75px">GENDER</td>
                    <td width="150px" height="75px">
                        <select name="gender">
                            <option>Select</option>
                            <option>Female</option>
                            <option>Male</option>
                        </select>
                    </td>

                </tr>
                <tr>
                    <td width="125px" height="75px" >SELECT YOUR BLOOD GROUP</td>
                    <td width="125px" height="75px">
                        <select name="bgroup" ,border-style= dashed>
                            <option></option>
                            <option>A+</option>
                            <option>A-</option>
                            <option>B+</option>
                            <option>B-</option>
                            <option>AB+</option>
                            <option>AB-</option>
                            <option>O+</option>
                            <option>O-</option>
                        </select>
                    </td>
                    <td width="125px" height="75px" >EXCHANGE BLOOD GROUP</td>
                    <td width="125px" height="75px">
                        <select name="exbgroup">
                            <option></option>
                            <option>A+</option>
                            <option>A-</option>
                            <option>B+</option>
                            <option>B-</option>
                            <option>AB+</option>
                            <option>AB-</option>
                            <option>O+</option>
                            <option>O-</option>
                        </select>
                    </td></tr><tr>
                    <td width="150px" height="75px">ENTER DONOR MAIL-ID</td>
                    <td width="150px" height="75px"><input type="text" name="demail" placeholder="                      @gmail.com"></td>
                    <td width="150px" height="75px">MAIL-ID</td>
                    <td width="150px" height="75px"><input type="text" name="email" placeholder="                      @gmail.com"></td>

                </tr>
                <tr>
                    <td weight="75px" height="100px">ADDRESS</td>
                    <td width="250px" height="100px"><textarea name="address" rows="4"></textarea></td>
                </tr>
                <tr>
                    <td weight="75px" height="30px"></td>
                </tr>
                <tr>
                <td><input type="submit" name="submit" value="SAVE"></td>
                </tr>
                
    
    <?php
    if(isset($_POST['submit']))
    {
        $name=$_POST['name'];
        $mnum=$_POST['mnum'];
        $age=$_POST['age'];
        $gender=$_POST['gender'];
        $bgroup=$_POST['bgroup'];
        $exbgroup=$_POST['exbgroup'];
        $demail=$_POST['demail'];
        $email=$_POST['email'];
        $address=$_POST['address'];
        
        $q2="DELETE from donor_registration where bgroup='$exbgroup' AND email='$demail'";
        $st1=$db->prepare($q2);
        $st1->execute();
        $q3=$db->prepare("INSERT INTO donor_registration (name,mnum,age,gender,bgroup,email,address) VALUES(:name,:mnum,:age,:gender,:bgroup,:email,:address)");
        $q3->bindValue('name',$name);
        $q3->bindValue('mnum',$mnum);
        $q3->bindValue('age',$age);
        $q3->bindValue('gender',$gender);
        $q3->bindValue('bgroup',$bgroup);
        $q3->bindValue('email',$email);
        $q3->bindValue('address',$address);
        $q3->execute();
        $q=$db->prepare("INSERT INTO exchange_b (name,mnum,age,gender,bgroup,exbgroup,demail,email,address) VALUES(:name,:mnum,:age,:gender,:bgroup,:exbgroup,:demail,:email,:address)");
        $q->bindValue('name',$name);
        $q->bindValue('mnum',$mnum);
        $q->bindValue('age',$age);
        $q->bindValue('gender',$gender);
        $q->bindValue('bgroup',$bgroup);
        $q->bindValue('exbgroup',$exbgroup);
        $q->bindValue('demail',$demail);
        $q->bindValue('email',$email);
        $q->bindValue('address',$address);
        if($q->execute())
        {
            echo "<script>alert('Blood Exchange Registration Successfull')</script>";
        }
        else{
            echo "<script>alert('Blood Exchange Registration fail')</script>";
        }
    }
    ?><tr>
        <td>  </td>
    </tr>
    <tr>
        <td>  </td>
    </tr>
    <tr>
        <td>  </td>
    </tr>
    </table>
    </form>
                </tr>
        </div><br>
    
    </div> 
    <br><br><br><br><br><br>  <br><br><br><br><br><br>
    
    <div id="footer"><h3 align="center">Copyright@DBP2021-B07</h3>
    <p align="center"><a href="logout.php"> Logout</a></p></div>
    </div>
</div>
</body>
</html>