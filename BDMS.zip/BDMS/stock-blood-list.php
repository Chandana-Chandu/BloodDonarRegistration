<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Blood Stock List</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <style type="text/css">
        td{
            width:200px;
            height:40px;
            background-color:#acacac;
        }
        #form1{
    width:100%;
    height:100%;
    color: black;
        }
    </style>
</head>
<body>
<div id= "full">
    <div id="inner_full">
        <div id="header"><a href="admin-home.php"><h1 align="center">Blood Donor Management System</h1></a></div>
        <div id="body">
        <br>
        <?php
        $uname=$_SESSION['uname'];
        if(!$uname)
        {
            header("Location:index.php");
        }
        ?>
        <h1 style="color:#000f89"  align="center">Blood Stock List</h1><br>
        <center><div id="form1">
            <table>
                <tr>
                <td><b> <font color="#5218fa">NAME</font></b></td>
                <td><b><font color="#5218fa">QUANTITY</font></b></td>
                </tr>
                    <tr>
                    <td>A+</td>
                    <td>
                        <?php
                        $q=$db->query("SELECT * FROM donor_registration WHERE bgroup='A+'");
                        echo $row=$q->rowcount();
                        ?>
                    </td>
                    </tr>
                    <tr>
                    <td>A-</td>
                    <td> <?php
                        $q=$db->query("SELECT * FROM donor_registration WHERE bgroup='A-'");
                        echo $row=$q->rowcount();
                        ?></td>
                    </tr>
                    <tr>
                    <td>B+</td>
                    <td>
                    <?php
                        $q=$db->query("SELECT * FROM donor_registration WHERE bgroup='B+'");
                        echo $row=$q->rowcount();
                        ?>
                    </td>
                    </tr>
                    <tr>
                    <td>B-</td>
                    <td>
                    <?php
                        $q=$db->query("SELECT * FROM donor_registration WHERE bgroup='B-'");
                        echo $row=$q->rowcount();
                        ?>
                    </td>
                    </tr>
                    <tr>
                    <td>AB+</td>
                    <td>
                    <?php
                        $q=$db->query("SELECT * FROM donor_registration WHERE bgroup='AB+'");
                        echo $row=$q->rowcount();
                        ?>
                    </td>
                    </tr>
                    <tr>
                    <td>AB-</td>
                    <td>
                    <?php
                        $q=$db->query("SELECT * FROM donor_registration WHERE bgroup='AB-'");
                        echo $row=$q->rowcount();
                        ?>
                    </td>
                    </tr>
                    <tr>
                    <td>O+</td>
                    <td>
                        <?php
                        $q=$db->query("SELECT * FROM donor_registration WHERE bgroup='O+'");
                        echo $row=$q->rowcount();
                        ?>
                    </td>
                    </tr>
                    <tr>
                    <td>O-</td>
                    <td> <?php
                        $q=$db->query("SELECT * FROM donor_registration WHERE bgroup='O-'");
                        echo $row=$q->rowcount();
                        ?></td>
                    </tr>

                
            </table>
        </div><br>
    
    </div> 
    </div>
</div></center>
</body>
</html>