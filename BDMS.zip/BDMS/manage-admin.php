<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Manage Page</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <style>
        #form{
    /* padding: auto; */
    width:35%;
    height: 270px;
    background-color: #ffb3de;
    color: black;
    border-radius: 10px;
}
input[type=submit]
{
    padding: 10px;
    background-color: #ffb3de;
    color: black;
}

    </style>

</head>
<body>
<div id= "full">
    <div id="inner_full">
        <div id="header"><a href="admin-home.php"><h1 align="center">Blood Bank Management System</h1></a></div>
        <div id="body">
        <br><br>
        <?php
        $uname=$_SESSION['uname'];
        if(!$uname)
        {
            header("Location:index.php");
        }
        ?>
        <h1 style="color:#c71585" align="center">Add,Delete and Update Admin</h1><br><br>
        <center><div id="form">
            <form action="" method="post">
            <table align="center">
                <tr>
                    <td width="100px" height="75px" >Enter Admin ID</td>
                    <td width="100px" height="75px"><input type="text" name="id"></td>
                </tr>
                <tr>
                    <td width="100px" height="75px" >Enter Admin Name</td>
                    <td width="100px" height="75px"><input type="text" name="uname"></td>
                </tr>
                <tr>
                    <td width="150px" height="75px">Enter Password</td>
                    <td width="150px" height="75px"><input type="text" name="pass"></td>

                </tr>
                <br>
                <tr>
                <td width="100px" height="50px"></td>
                </tr>
                <!-- <tr>
                <td width="150px" height="75px"></td>
                </tr> -->

                <tr>
                <td><input type="submit" name="add" value="ADD"></td>
                <td colour="black" background-color="red"><input type="submit" name="delete" value="DELETE"></td>
                <td><input type="submit" name="update" value="UPDATE"></td>
                

                </tr>
            </table>
    </form>
    
    <?php
    if(isset($_POST['add']))
    {
        $id=$_POST['id'];
        $uname=$_POST['uname'];
        $pass=$_POST['pass'];
        $q=$db->prepare("INSERT INTO admin (id,uname,pass) VALUES(:id,:uname,:pass)");
        $q->bindValue('id',$id);
        $q->bindValue('uname',$uname);
        $q->bindValue('pass',$pass);
        if($q->execute())
        {
            echo "<script>alert('Admin Added Successfully')</script>";
        }
        else{
            echo "<script>alert('Adding of Admin is Failured')</script>";
        }
    }
    ?>

    <?php
    if(isset($_POST['delete']))
    {
        $id=$_POST['id'];
        $uname=$_POST['uname'];
        $pass=$_POST['pass'];
        $q1=$db->prepare("DELETE from admin where id='$id' and uname='$uname' and pass='$pass'");
        if($q1->execute())
        {
            echo "<script>alert('Admin Deleted Successfully')</script>";
        }
        else{
            echo "<script>alert('Deletion of Admin is Failured')</script>";
        }
    }
    ?>

    <?php
    if(isset($_POST['update']))
    {
        $id=$_POST['id'];
        $uname=$_POST['uname'];
        $pass=$_POST['pass'];
        $q2=$db->prepare("UPDATE admin SET uname='$uname',pass='$pass' where id='$id'");
        if($q2->execute())
        {
            echo "<script>alert('Admin Updated Successfully')</script>";
        }
        else{
            echo "<script>alert('Updat of Admin is Failured')</script>";
        }
    }
    ?>

        </center></div><br>
    
    </div> 
    
    <br><br><br><br><br><br>  <br><br>
    <div id="footer"><h3 align="center">Copyright@DBP2021-B07</h3>
    <p align="center"><a href="logout.php"> Logout</a></p></div>
    </div>
</div>
</body>
</html>