<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Donar's List</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <style type="text/css">
        td{
            width:200px;
            height:40px;
            background-color:#acacac;
        }
        #form1{
    width:100%;
    height:100%;
    color: black;
        }
    </style>
</head>
<body>
<div id= "full">
    <div id="inner_full">
        <div id="header"><a href="admin-home.php"><h1 align="center">Blood Donor Management System</h1></a></div>
        <div id="body">
        <br>
        <?php
        $uname=$_SESSION['uname'];
        if(!$uname)
        {
            header("Location:index.php");
        }
        ?>
        <h1 style="color:#000f89"  align="center">Donor's List</h1><br>
        <div id="form1">
            <center><table>
                <tr>
                <td><b> <font color="#5218fa">FULL NAME</font></b></td>
                <td><b><font color="#5218fa">MOBILE NUMBER</font></b></td>
                <td><b><font color="#5218fa">AGE</font></b></td>
                <td><b><font color="#5218fa">GENDER</font></b></td>
                <td><b><font color="#5218fa">BLOOD GROUP</font></b></td>
                <td><b><font color="#5218fa">MAIL-ID</font></b></td>
                <td><b><font color="#5218fa">ADDRESS</font></b></td>
                </tr>
                <?php
                $q=$db->query("SELECT * FROM donor_registration");
                while($r1=$q->fetch(PDO::FETCH_OBJ))
                {
                    ?>
                    <tr>
                    <td> <?= $r1->name; ?> </td>
                    <td><?= $r1->mnum; ?></td>
                    <td><?= $r1->age; ?></td>
                    <td><?= $r1->gender; ?></td>
                    <td><?= $r1->bgroup; ?></td>
                    <td><?= $r1->email; ?></td>
                    <td><?= $r1->address; ?></td>
                </tr>
                    <?php
                }
                ?>
                
            </table></center>
        </div><br>
    
    </div> 
    </div>
</div>
</body>
</html>