<?php
include('../connection.php');
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Contact Admin Page</title>
    <link rel="stylesheet" type="text/css" href="css/style1.css">
    <style>
        p{
            font-size: large;
        }
        #address{
            color:#696969;
        }
        #form{
    
    width:25%;
    height:330px;
    background-color:#eae0c8;
    color:#004b49;
    border-radius: 10px;
    }
    input[type=submit]
{
    padding: 10px;
    background-color:#eae0c8;
    color:#004b49;
}
    </style>
</head>
<body>
    <div class="header">
        <div class="logo"><h2 align="center">Blood Donor Management System</h2></div>
       <div class="nav">
           <div id="a"><a href="index1.php">Home</a> </div>
           <div id="b"><a href="become-donor.php">Become Donor</a> </div>
           <div id="c"><a href="contact-us.php">Contact Us</a> </div>
           <div id="d"><a href="login.php">Login</a> </div>
        </div>
    </div>
    <center><h1 style="color:#c154c1">Contact Details</h1>

           <div id="address"><b>ADDRESS</b> : MITM</div>
           <div id="address"><b>MOBILE NUMBER</b> : 1234567890</div>
           <div id="address"><b>MAIL-ID</b> : abcd@gmail.com</div>
           <br>

           <h1 style="color:#ffa500">Fill the form if u have any Query</h1>
        <div id="form">
            <form action="" method="post">
           <table>
                <tr>
                    <td width="100px" height="75px" align="center">FULL NAME</td>
                    <td width="500px" height="75px" align="center"><input type="text" name="name" placeholder="Enter Full Name"></td>

                </tr>
                <tr>
                <td width="500px" height="75px" align="center">MOBILE NUMBER</td>
                <td width="500px" height="75px" align="center"><input type="text" name="mnum" placeholder="Enter Mobile Number" class="form-control" required></td>
                </tr>
                <tr>
                    <td width="150px" height="75px" align="center">MAIL-ID</td>
                    <td width="500px" height="75px" align="center"><input type="text" name="email" placeholder="                      @gmail.com"></td>

                </tr>
                <tr>
                    <td weidth="150px" height="100px" align="center">MESSAGE</td>
                    <td width="500px" height="100px" align="center"><textarea name="message" rows="4" class="form-control" required></textarea></td>
                </tr>
                <tr>
                    <td><input type="submit" name="submit" value="SAVE"></td>
                </tr>
            </table>
            </form>
            <?php
    if(isset($_POST['submit']))
    {
        $name=$_POST['name'];
        $mnum=$_POST['mnum'];
        $email=$_POST['email'];
        $message=$_POST['message'];
        $q=$db->prepare("INSERT INTO query (name,mnum,email,message) VALUES(:name,:mnum,:email,:message)");
        $q->bindValue('name',$name);
        $q->bindValue('mnum',$mnum);
        $q->bindValue('email',$email);
        $q->bindValue('message',$message);
        if($q->execute())
        {
            echo "<script>alert('Your message sent Successfully')</script>";
        }
        else{
            echo "<script>alert('Unable to send message')</script>";
        }
    }
    ?>
</div></center>
<br><br><br>
    <div class="footer"><h3 align="center">Copyright@DBP2021-B07</h3></div>

</body>
</html>