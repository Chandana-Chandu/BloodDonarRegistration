<?php
include('../connection.php');
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Donor Page</title>
    <link rel="stylesheet" type="text/css" href="css/style1.css">
    <style>
#form{
    width:50%;
    height:350px;
    background-color:#c0c0c0;
    color: #800080;
    border-radius: 10px;
}
input[type=submit]
{
    padding: 10px;
    background-color:#c0c0c0;
    color: #800080;

}
h1{
    color:#191970;
}
    </style>
</head>
<body>
    <div class="header">
        <div class="logo"><h2 align="center">Blood Donor Management System</h2></div>
       <div class="nav">
           <div id="a"><a href="index1.php">Home</a> </div>
           <div id="b"><a href="become-donor.php">Become Donor</a> </div>
           <div id="c"><a href="contact-us.php">Contact Us</a> </div>
           <div id="d"><a href="login.php">Login</a> </div>
        </div>
    </div>
    <br><br>
    <h1>Donor Registration</h1><br>
        <div id="form">
            <form action="" method="post">
            <table>
                <tr>
                    <td width="100px" height="75px" >FULL NAME</td>
                    <td width="100px" height="75px"><input type="text" name="name" placeholder="Enter Full Name"></td>
                    <td width="150px" height="75px">MOBILE NUMBER</td>
                    <td width="100px" height="75px"><input type="text" name="mnum" placeholder="Enter Mobile Number"></td>

                </tr>
                <tr>
                    <td width="100px" height="75px" >AGE</td>
                    <td width="100px" height="75px"><input type="text" name="age" placeholder="Enter your Age"></td>
                    <td width="150px" height="75px">GENDER</td>
                    <td width="150px" height="75px">
                        <select name="gender">
                            <option>Select</option>
                            <option>Female</option>
                            <option>Male</option>
                        </select>
                    </td>

                </tr>
                <tr>
                    <td width="125px" height="75px" >BLOOD GROUP</td>
                    <td width="125px" height="75px">
                        <select name="bgroup">
                            <option>Select</option>
                            <option>A+</option>
                            <option>A-</option>
                            <option>B+</option>
                            <option>B-</option>
                            <option>AB+</option>
                            <option>AB-</option>
                            <option>O+</option>
                            <option>O-</option>
                        </select>
                    </td>
                    <td width="150px" height="75px">MAIL-ID</td>
                    <td width="150px" height="75px"><input type="text" name="email" placeholder="                      @gmail.com"></td>

                </tr>
                <tr>
                    <td weight="75px" height="100px">ADDRESS</td>
                    <td width="250px" height="100px"><textarea name="address" rows="4"></textarea></td>
                </tr><br>
                <tr>
                    <td><input type="submit" name="submit" value="SAVE"></td>
                </tr>
            </table>
            </form>
            <?php
    if(isset($_POST['submit']))
    {
        $name=$_POST['name'];
        $mnum=$_POST['mnum'];
        $age=$_POST['age'];
        $gender=$_POST['gender'];
        $bgroup=$_POST['bgroup'];
        $email=$_POST['email'];
        $address=$_POST['address'];
        $q=$db->prepare("INSERT INTO donor_registration (name,mnum,age,gender,bgroup,email,address) VALUES(:name,:mnum,:age,:gender,:bgroup,:email,:address)");
        $q->bindValue('name',$name);
        $q->bindValue('mnum',$mnum);
        $q->bindValue('age',$age);
        $q->bindValue('gender',$gender);
        $q->bindValue('bgroup',$bgroup);
        $q->bindValue('email',$email);
        $q->bindValue('address',$address);
        if($q->execute())
        {
            echo "<script>alert('Donar Registration Successfull')</script>";
        }
        else{
            echo "<script>alert('Donar Registration fail')</script>";
        }
    }
        ?>
</div>
<br><br>
    <div class="footer"><h3 align="center">Copyright@DBP2021-B07</h3></div>

</body>
</html>