<?php
header("location:../")
?>