<!DOCTYPE html>
<html lang="en">
<head>
    <title>Home Page</title>
    <link rel="stylesheet" type="text/css" href="css/style1.css">
    <style>
        p{
            font-size: large;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="logo"><h2 align="center">Blood Donor Management System</h2></div>
       <div class="nav">
           <div id="a"><a href="index1.php">Home</a> </div>
           <div id="b"><a href="become-donor.php">Become Donor</a> </div>
           <div id="c"><a href="contact-us.php">Contact Us</a> </div>
           <div id="d"><a href="login.php">Login</a> </div>
        </div>
    </div>
    <div class="banner"></div>
    <div class="container">
        <br>
        <h1 align="center" style="color:orange">Doctor's Information</h1>
        <br>
        <center><table border="1px">
            <tr>
                <td width="200px" height="50px" style="color:green"><center><b>DOCTOR NAME</b></center></td>
                <td width="200px" height="50px" style="color:green"><center><b>MOBILE NO</b></center></td>
                <td width="200px" height="50px" style="color:green"><center><b>ADDRESS</b></center></td>
                <td width="200px" height="50px" style="color:green"><center><b>SPECIALIZATION</b></center></td>
            </tr>
            <tr>
                <td width="200px" height="50px" style="color:black"><center><b>Demp Name</b></center></td>
                <td width="200px" height="50px" style="color:black"><center><b>91245678</b></center></td>
                <td width="200px" height="50px" style="color:black"><center><b>xyz</b></center></td>
                <td width="200px" height="50px" style="color:black"><center><b>abc</b></center></td>
            </tr>
        </table></center>
        <br>
    </div>
    <h1>About Blood Donation</h1>
    <p>Blood is the most precious gift that anyone can give to another person-the gift of life.
         A decision to donate your blood can save a life, or even several if your blood is separated into its components-red cells, 
         platelets and plasma-which can be used individually for patients with specific conditions.</p>

<p>Safe blood saves lives. Blood is needed by women with complications during pregnancy and childbirth, children with severe anaemia,
     often resulting from malaria or malnutrition, accident victims and surgical and cancer patients.</p>

<p>There is a constant need for a regular supply of blood because it can be stored only for a limited period of time before use.
     Regular blood donation by a sufficient number of healthy people is needed to ensure that blood will always be available whenever
      and wherever it is needed.</p>
    <div class="footer"><h3 align="center">Copyright@DBP2021-B07</h3></div>

</body>
</html>