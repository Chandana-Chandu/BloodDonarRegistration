<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <style>
        #header{
    width:100%;
    height:50px;
    background-color:#32174d;
    color:white;
}
    </style>
</head>
<body>
<div id= "full">
    <div id="inner_full">
        <div id="header"><a href="admin-home.php"><h1 align="center">Blood Donor Management System</h1></a></div>
        <div id="body">
        <br>
        <?php
        $uname=$_SESSION['uname'];
        if(!$uname)
        {
            header("Location:index.php");
        }
        ?>
        <h1 style="color:#000f89">Welcome Admin</h1><br><br>
        <ul>
            <li><a href="donor-reg.php">Donor Registration</a></li>
            <li><a href="donor-list.php">Donor List</a></li>
            <li><a href="stock-blood-list.php">Blood Stock List</a></li>
        </ul><br><br><br><br><br>
        <ul>
            <li><a href="exchange-blood-donar-registration.php">Exchange Blood Donar Registration</a></li>
            <li><a href="exchange-blood-list.php">Exchange Blood List</a></li>
            <li><a href="manage-admin.php">Manage Admin</a></li>
        </ul>
        </div>
    <div id="footer"><h3 align="center">Copyright@DBP2021-B07</h3>
    <p align="center"><a href="logout.php"> Logout</a></p></div>
    </div>
</div>
</body>
</html>