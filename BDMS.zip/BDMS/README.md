
#  Technology Used
1. HTML5
2. CSS3
3. Core/Procedural PHP programming language
4. MySQL Relational Database


#  Features
1. Visitors/Users can register them self as donors. 
2. They also can also contact admin/hospital easily from the website.
3. Admin can Manage Admin, Register donor and Exchange blood among donors.
4. Admin can also track who are admins login to the website.

## How to Download the Project and Run on your PC?

### Pre-Requisites:

1. Download and Install XAMPP

[Click Here to Download](https://www.apachefriends.org/index.html)

2. Install any Text Editor (Sublime Text or Visual Studio Code or Atom or Brackets)

### Installation

1. Download as as Zip 
2. Move this project to Root Directory
```
Local Disc C: -> xampp -> htdocs -> 'this project'
```
*Local Disk C is the location where xampp was installed*

3. Open XAMPP Control Panel and Start 'Apache' and 'MySQL'

4. Import Database

a. Open 'phpmyadmin' in your browser
b. Create a Database
c. Import the SQL file provided with this project

5. In a new tab of the your browser , enter the address "localhost/BDMS/user/index1.php" [this page directs u to the user page].

6. In order to login as admin , click login[which is in user page]
   Enter user-ID : 2
   Enter username : varsha s
   Enter Password : mysore
   or
   Enter user-ID : 3
   Enter username : chandana
   Enter Password : mandya
